const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const toastEl = $("#toast");
let toastTimer;
function toast(message){toastEl.textContent=message;toastEl.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove("show"),2800);}
$("#year").textContent = new Date().getFullYear();

// Theme preference
const savedTheme = localStorage.getItem("vyntra-theme");
if(savedTheme) document.documentElement.dataset.theme=savedTheme;
function updateThemeIcon(){ $("#themeToggle").textContent=document.documentElement.dataset.theme==="dark"?"☾":"☼"; }
updateThemeIcon();
$("#themeToggle").addEventListener("click",()=>{
  const next=document.documentElement.dataset.theme==="dark"?"light":"dark";
  document.documentElement.dataset.theme=next;localStorage.setItem("vyntra-theme",next);updateThemeIcon();
});

// Mobile navigation
$("#menuBtn").addEventListener("click",()=>$(".desktop-nav").classList.toggle("open"));
$$(".desktop-nav a").forEach(a=>a.addEventListener("click",()=>$(".desktop-nav").classList.remove("open")));

// Wallpaper demo catalogue. Remote images are for visual preview only.
const wallpapers=[
 {id:"night-drive",name:"Midnight Drive",category:"Cars",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=85",tag:"BESTSELLER"},
 {id:"alpine",name:"Alpine Silence",category:"Nature",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=85",tag:"POPULAR"},
 {id:"dark-flow",name:"Dark Flow",category:"AMOLED",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=900&q=85",tag:"AMOLED"},
 {id:"violet",name:"Violet Dimension",category:"Abstract",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=900&q=85",tag:"NEW"},
 {id:"cosmos",name:"Into the Cosmos",category:"Space",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=900&q=85",tag:"SPACE"},
 {id:"coast",name:"Coastal Escape",category:"Nature",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=900&q=85",tag:"CALM"},
 {id:"supercar",name:"Redline",category:"Cars",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=85",tag:"SPORT"},
 {id:"abstract-night",name:"After Hours",category:"Abstract",resolution:"4K · 2160 × 3840",price:10,img:"https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85",tag:"DARK"}
];
let activeCategory="All", selectedWallpaper=null;
function renderWallpapers(){
 const list=wallpapers.filter(w=>activeCategory==="All"||w.category===activeCategory);
 $("#wallpaperGrid").innerHTML=list.map(w=>`<article class="wallpaper-card">
  <div class="wallpaper-image"><img loading="lazy" src="${w.img}" alt="${w.name} wallpaper preview"><span class="wallpaper-badge">${w.tag}</span></div>
  <div class="wallpaper-info"><h3>${w.name}</h3><div class="wallpaper-meta">${w.category} · ${w.resolution}</div>
  <div class="wallpaper-bottom"><span class="price">₹${w.price}</span><button class="buy-button" data-buy="${w.id}">Buy demo ↗</button></div></div></article>`).join("");
 $$("[data-buy]").forEach(btn=>btn.addEventListener("click",()=>openPurchase(btn.dataset.buy)));
}
renderWallpapers();
$$(".filter-chip").forEach(btn=>btn.addEventListener("click",()=>{
 activeCategory=btn.dataset.category;$$(".filter-chip").forEach(b=>b.classList.toggle("active",b===btn));renderWallpapers();
}));
const purchaseDialog=$("#purchaseDialog");
function openPurchase(id){
 selectedWallpaper=wallpapers.find(w=>w.id===id);if(!selectedWallpaper)return;
 $("#purchaseTitle").textContent=selectedWallpaper.name;$("#purchaseDescription").textContent=`You selected the ${selectedWallpaper.category} wallpaper. This is a demo order only.`;
 $("#purchasePrice").textContent=`₹${selectedWallpaper.price}`;purchaseDialog.showModal();
}
$("#cancelDemoPurchase").addEventListener("click",()=>purchaseDialog.close());
$("#confirmDemoPurchase").addEventListener("click",()=>{
 purchaseDialog.close();if(selectedWallpaper)toast(`Demo order recorded for ${selectedWallpaper.name}. No payment taken.`);
});

// Tool navigation + tool panels
const toolNavLabels={image:["IMAGE STUDIO","Resize and compress images","Choose an image, adjust its output size and download the result."],qr:["QR CODE GENERATOR","Create a QR code","Turn a link, text or contact snippet into a QR code."],pdf:["IMAGE TO PDF","Turn images into a PDF","Select images and create a printable PDF using your browser's print dialog."],calculator:["QUICK CALCULATOR","Do a quick calculation","A simple calculator for everyday maths."],percentage:["PERCENTAGE TOOL","Calculate percentages","Find a percentage of a number or calculate percentage change."],age:["AGE CALCULATOR","Calculate your age","Find the time between your date of birth and today."]};
function renderTool(type){
 $$(".tool-nav-item").forEach(b=>b.classList.toggle("active",b.dataset.tool===type));
 const [kicker,title,desc]=toolNavLabels[type];
 let body="";
 if(type==="image") body=`<div class="upload-zone" id="imageDrop"><input type="file" id="imageInput" accept="image/*" hidden><div class="upload-icon">↑</div><strong>Drop an image here</strong><span>or choose a file from your device</span><button class="button secondary small" id="chooseImage">Choose image</button></div><div class="image-options"><label>Width (px)<input id="imageWidth" type="number" min="1" max="10000" placeholder="Original"></label><label>Quality<select id="imageQuality"><option value="0.55">Smaller file</option><option value="0.8" selected>Balanced</option><option value="0.95">High quality</option></select></label><label>Format<select id="imageFormat"><option value="image/jpeg">JPG</option><option value="image/png">PNG</option><option value="image/webp">WebP</option></select></label></div><div id="imagePreviewWrap" class="image-preview-wrap hidden"><img id="imagePreview" alt="Selected image preview"><div id="imageMeta" class="muted"></div></div><button class="button primary" id="processImage" disabled>Process & download</button><p class="microcopy">Image processing happens locally in this browser. Transparent areas may turn white when exporting as JPG.</p>`;
 if(type==="qr") body=`<form class="tool-form" id="qrForm"><label>Text or URL<input id="qrText" required placeholder="https://example.com"></label><button class="button primary" type="submit">Generate QR code</button></form><div id="qrOutput" class="qr-output"></div><p class="microcopy">QR generation uses a small library loaded from a CDN, so internet access is required for this tool.</p>`;
 if(type==="pdf") body=`<form class="tool-form" id="pdfForm"><label>Choose image files<input id="pdfImages" type="file" accept="image/*" multiple required></label><label>Page size<select id="pdfPageSize"><option value="A4">A4</option><option value="Letter">Letter</option></select></label><button class="button primary" type="submit">Open printable PDF layout</button></form><div id="pdfResult" class="tool-result hidden"></div><p class="microcopy">Your browser opens a print-ready page. Choose “Save as PDF” in the print destination. This is a client-side helper, not a full PDF editor.</p>`;
 if(type==="calculator") body=`<div class="tool-form"><label>Calculation<input id="calcExpression" placeholder="e.g. (25 + 15) * 2"></label><button class="button primary" id="calcButton" type="button">Calculate</button></div><div id="calcResult" class="tool-result hidden"></div><p class="microcopy">Supports basic arithmetic, brackets, decimals and percentages written as decimals (e.g. 0.15 for 15%).</p>`;
 if(type==="percentage") body=`<div class="tool-form"><div class="row-fields"><label>Percentage (%)<input id="percentValue" type="number" placeholder="e.g. 18"></label><label>Number<input id="percentBase" type="number" placeholder="e.g. 500"></label></div><button class="button primary" id="percentButton" type="button">Find percentage</button><div class="row-fields"><label>Original value<input id="changeOld" type="number" placeholder="Old value"></label><label>New value<input id="changeNew" type="number" placeholder="New value"></label></div><button class="button secondary" id="changeButton" type="button">Find percentage change</button></div><div id="percentResult" class="tool-result hidden"></div>`;
 if(type==="age") body=`<div class="tool-form"><label>Date of birth<input id="birthDate" type="date" required></label><button class="button primary" id="ageButton" type="button">Calculate my age</button></div><div id="ageResult" class="tool-result hidden"></div>`;
 $("#toolPanel").innerHTML=`<div class="tool-panel-head"><div><span class="tool-kicker">${kicker}</span><h3>${title}</h3><p>${desc}</p></div><span class="tool-symbol">${({image:"▧",qr:"⌗",pdf:"▤",calculator:"＋",percentage:"%",age:"◷"})[type]}</span></div>${body}`;
 if(type==="image") initImageTool();if(type==="qr") initQrTool();if(type==="pdf") initPdfTool();if(type==="calculator") initCalculator();if(type==="percentage") initPercentage();if(type==="age") initAge();
}
$$(".tool-nav-item").forEach(btn=>btn.addEventListener("click",()=>renderTool(btn.dataset.tool)));
function initImageTool(){
 const input=$("#imageInput"),choose=$("#chooseImage"),drop=$("#imageDrop"),previewWrap=$("#imagePreviewWrap"),preview=$("#imagePreview"),meta=$("#imageMeta"),process=$("#processImage");
 let sourceImage=null,sourceName="image";
 choose.addEventListener("click",()=>input.click());
 input.addEventListener("change",()=>loadImage(input.files[0]));
 drop.addEventListener("dragover",e=>{e.preventDefault();drop.style.borderColor="var(--primary)"});
 drop.addEventListener("dragleave",()=>drop.style.borderColor="");
 drop.addEventListener("drop",e=>{e.preventDefault();drop.style.borderColor="";loadImage(e.dataTransfer.files[0])});
 function loadImage(file){
  if(!file)return;if(!file.type.startsWith("image/")){toast("Please choose an image file.");return}
  sourceName=file.name.replace(/\.[^.]+$/,"")||"image";const url=URL.createObjectURL(file);sourceImage=new Image();
  sourceImage.onload=()=>{preview.src=url;previewWrap.classList.remove("hidden");meta.textContent=`${sourceImage.naturalWidth} × ${sourceImage.naturalHeight}px · ${(file.size/1024).toFixed(0)} KB`;$("#imageWidth").placeholder=sourceImage.naturalWidth;process.disabled=false;};
  sourceImage.onerror=()=>toast("This image could not be opened.");sourceImage.src=url;
 }
 process.addEventListener("click",()=>{
  if(!sourceImage)return;let width=Number($("#imageWidth").value)||sourceImage.naturalWidth;
  if(width<1||width>10000){toast("Enter a width between 1 and 10,000 px.");return}
  const height=Math.max(1,Math.round(width*sourceImage.naturalHeight/sourceImage.naturalWidth));
  const canvas=document.createElement("canvas");canvas.width=width;canvas.height=height;const ctx=canvas.getContext("2d");
  if($("#imageFormat").value==="image/jpeg"){ctx.fillStyle="#fff";ctx.fillRect(0,0,width,height)}
  ctx.drawImage(sourceImage,0,0,width,height);
  canvas.toBlob(blob=>{if(!blob){toast("Could not export this image.");return}const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`${sourceName}-vyntra.${({"image/jpeg":"jpg","image/png":"png","image/webp":"webp"})[$("#imageFormat").value]}`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);toast("Image processed and downloaded.");},$("#imageFormat").value,Number($("#imageQuality").value));
 });
}
function initQrTool(){
 $("#qrForm").addEventListener("submit",e=>{
  e.preventDefault();const value=$("#qrText").value.trim();if(!value)return;const out=$("#qrOutput");out.innerHTML="";
  if(typeof QRCode==="undefined"){out.innerHTML="<p class='muted'>QR library is unavailable. Check your internet connection and reload.</p>";return}
  new QRCode(out,{text:value,width:190,height:190,colorDark:"#17182b",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});
  const dl=document.createElement("button");dl.className="button secondary small";dl.textContent="Download QR image";dl.style.margin="10px auto";dl.style.display="block";dl.addEventListener("click",()=>{const img=out.querySelector("img"),canvas=out.querySelector("canvas");const a=document.createElement("a");a.href=img?.src||canvas?.toDataURL("image/png");a.download="vyntra-qr.png";a.click()});out.appendChild(dl);
 });
}
function initPdfTool(){
 $("#pdfForm").addEventListener("submit",e=>{
  e.preventDefault();const files=[...$("#pdfImages").files];if(!files.length)return;
  const pageSize=$("#pdfPageSize").value;const urls=files.map(f=>URL.createObjectURL(f));
  const win=window.open("","_blank");if(!win){toast("Allow pop-ups to create a print-ready PDF.");return}
  win.document.write(`<!doctype html><html><head><title>Vyntra image PDF</title><style>@page{size:${pageSize};margin:12mm}body{font-family:Arial,sans-serif;margin:0}.page{page-break-after:always;display:flex;align-items:center;justify-content:center;height:95vh}.page:last-child{page-break-after:auto}img{max-width:100%;max-height:95%;object-fit:contain}</style></head><body>${urls.map(u=>`<div class="page"><img src="${u}"></div>`).join("")}<script>window.onload=()=>setTimeout(()=>window.print(),500)<\/script></body></html>`);win.document.close();
  $("#pdfResult").classList.remove("hidden");$("#pdfResult").textContent=`Opened ${files.length} image(s) in a print-ready window. Choose “Save as PDF” in the print dialog.`;toast("Print-ready layout opened.");
 });
}
function initCalculator(){
 $("#calcButton").addEventListener("click",()=>{
  const expr=$("#calcExpression").value.trim(),out=$("#calcResult");out.classList.remove("hidden");
  // Only allow a narrow arithmetic character set before evaluating.
  if(!expr||!/^[\d\s.+\-*/()%]+$/.test(expr)){out.textContent="Enter a valid arithmetic expression.";return}
  try{const result=Function('"use strict";return ('+expr+')')();if(typeof result!=="number"||!Number.isFinite(result))throw Error();out.innerHTML=`Result: <strong>${result.toLocaleString(undefined,{maximumFractionDigits:8})}</strong>`}
  catch{out.textContent="That calculation could not be evaluated. Check the expression."}
 });
}
function initPercentage(){
 $("#percentButton").addEventListener("click",()=>{const p=Number($("#percentValue").value),b=Number($("#percentBase").value),out=$("#percentResult");out.classList.remove("hidden");if($("#percentValue").value===""||$("#percentBase").value===""){out.textContent="Enter both a percentage and a number.";return}out.innerHTML=`${p}% of ${b} = <strong>${(p/100*b).toLocaleString(undefined,{maximumFractionDigits:6})}</strong>`});
 $("#changeButton").addEventListener("click",()=>{const a=Number($("#changeOld").value),b=Number($("#changeNew").value),out=$("#percentResult");out.classList.remove("hidden");if($("#changeOld").value===""||$("#changeNew").value===""||a===0){out.textContent="Enter both values; the original value must not be zero.";return}const change=(b-a)/Math.abs(a)*100;out.innerHTML=`Percentage change: <strong>${change>0?"+":""}${change.toFixed(2)}%</strong> (${change>0?"increase":change<0?"decrease":"no change"})`});
}
function initAge(){
 const input=$("#birthDate");input.max=new Date().toISOString().slice(0,10);
 $("#ageButton").addEventListener("click",()=>{const out=$("#ageResult"),v=input.value;out.classList.remove("hidden");if(!v){out.textContent="Choose your date of birth.";return}const birth=new Date(v+"T00:00:00"),today=new Date();if(birth>today){out.textContent="Date of birth cannot be in the future.";return}let y=today.getFullYear()-birth.getFullYear(),m=today.getMonth()-birth.getMonth(),d=today.getDate()-birth.getDate();if(d<0){m--;d+=new Date(today.getFullYear(),today.getMonth(),0).getDate()}if(m<0){y--;m+=12}out.innerHTML=`You are <strong>${y} years, ${m} months and ${d} days</strong> old.`});
}
renderTool("image");

// Student tools
const notes=$("#quickNotes");notes.value=localStorage.getItem("vyntra-notes")||"";
let notesSaveTimer;notes.addEventListener("input",()=>{clearTimeout(notesSaveTimer);$("#notesStatus").textContent="Saving…";notesSaveTimer=setTimeout(()=>{localStorage.setItem("vyntra-notes",notes.value);$("#notesStatus").textContent="Saved only in this browser";},250)});
$("#clearNotes").addEventListener("click",()=>{notes.value="";localStorage.removeItem("vyntra-notes");$("#notesStatus").textContent="Notes cleared";});
let tasks=JSON.parse(localStorage.getItem("vyntra-tasks")||"[]");
function renderTasks(){const list=$("#taskList");list.innerHTML=tasks.map((t,i)=>`<li class="${t.done?"done":""}"><input type="checkbox" data-task-check="${i}" ${t.done?"checked":""} aria-label="Mark task complete"><label>${escapeHTML(t.text)}</label><button class="delete-task" data-task-delete="${i}" aria-label="Delete task">×</button></li>`).join("");$$("[data-task-check]").forEach(el=>el.addEventListener("change",()=>{tasks[Number(el.dataset.taskCheck)].done=el.checked;saveTasks()}));$$("[data-task-delete]").forEach(el=>el.addEventListener("click",()=>{tasks.splice(Number(el.dataset.taskDelete),1);saveTasks()}));}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function saveTasks(){localStorage.setItem("vyntra-tasks",JSON.stringify(tasks));renderTasks();}
$("#taskForm").addEventListener("submit",e=>{e.preventDefault();const text=$("#taskInput").value.trim();if(!text)return;tasks.unshift({text,done:false});$("#taskInput").value="";saveTasks();});renderTasks();
let timerSeconds=25*60,timerInterval=null;
function updateTimer(){const m=String(Math.floor(timerSeconds/60)).padStart(2,"0"),s=String(timerSeconds%60).padStart(2,"0");$("#timerDisplay").textContent=`${m}:${s}`;}
$("#timerStart").addEventListener("click",()=>{if(timerInterval){clearInterval(timerInterval);timerInterval=null;$("#timerStart").textContent="Resume focus";$("#timerStatus").textContent="Paused. Resume when ready.";return}$("#timerStart").textContent="Pause";$("#timerStatus").textContent="Focus time is running.";timerInterval=setInterval(()=>{timerSeconds--;updateTimer();if(timerSeconds<=0){clearInterval(timerInterval);timerInterval=null;$("#timerStart").textContent="Start again";$("#timerStatus").textContent="Session complete — take a short break!";toast("Focus session complete!");timerSeconds=25*60;updateTimer();}},1000);});
$("#timerReset").addEventListener("click",()=>{clearInterval(timerInterval);timerInterval=null;timerSeconds=25*60;updateTimer();$("#timerStart").textContent="Start focus";$("#timerStatus").textContent="Ready when you are.";});

// PWA installation flow
let deferredInstallPrompt=null;
const installDialog=$("#installDialog");
window.addEventListener("beforeinstallprompt",event=>{event.preventDefault();deferredInstallPrompt=event;$("#installBtn").classList.add("install-ready");$("#installMessage").textContent="Your browser says Vyntra can be installed on this device.";});
window.addEventListener("appinstalled",()=>{deferredInstallPrompt=null;installDialog.close();toast("Vyntra was installed successfully.");});
async function requestInstall(){
 if(deferredInstallPrompt){
  try{deferredInstallPrompt.prompt();const choice=await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;if(choice.outcome==="accepted"){installDialog.close();toast("Installation started.");}else{installDialog.showModal();}}
  catch{installDialog.showModal();}
 }else{
  const standalone=window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===true;
  if(standalone){toast("Vyntra is already running as an installed app.");return}
  $("#installMessage").textContent=location.protocol==="file:"?"Open this project through a local web server or an HTTPS host to enable PWA installation.":"Your browser has not offered a direct install prompt. Follow the device-specific steps below.";
  installDialog.showModal();
 }
}
$("#installBtn").addEventListener("click",requestInstall);
$("#installBtnBottom").addEventListener("click",requestInstall);
$("#installTryAgain").addEventListener("click",async()=>{if(deferredInstallPrompt){installDialog.close();await requestInstall()}else{toast("If no prompt appears, use your browser menu to install or add to Home Screen.");}});
$("#installClose").addEventListener("click",()=>installDialog.close());

// Service worker: requires localhost or HTTPS.
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost"||location.hostname==="127.0.0.1")){
 window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(err=>console.warn("Service worker registration failed",err)));
}
