# Vyntra PWA — Front-end demo

Vyntra is a responsive HTML, CSS and JavaScript prototype for an all-in-one digital utility and wallpaper platform.

## Included
- Responsive desktop/mobile layout
- Light/dark theme preference (stored in this browser)
- Wallpaper catalogue and category filters
- Clearly labelled simulated ₹10 checkout (no real payment)
- Client-side image resizing/compression/conversion
- QR generator (uses QRCode.js from a CDN, so it needs internet)
- Image-to-print/PDF helper (uses the browser print dialog; choose Save as PDF)
- Calculator, percentage calculator and age calculator
- Focus timer, quick notes and task checklist
- PWA manifest, SVG app icon and service worker
- Install button with native prompt when available and manual instructions otherwise

## Run locally
A PWA needs a secure context: HTTPS in production, or `localhost` during local development. Do not open `index.html` by double-clicking it and expect PWA installation to work.

### Option A: Python local server
1. Install Python if needed.
2. Open a terminal in this folder.
3. Run: `python -m http.server 8000`
4. Open `http://localhost:8000` in a supported browser.

### Option B: VS Code
Use the Live Server extension and open the provided local URL. `localhost` is treated as a secure context for development.

## Deploy
Upload the contents of this folder to a static HTTPS host (for example, GitHub Pages, Netlify or Cloudflare Pages). Make sure `index.html`, `manifest.json`, `service-worker.js`, `styles.css`, `app.js`, and the `icons` folder are at the published root.

After deployment, open the URL in a compatible browser and use the Install now button. Browser/device eligibility varies. Some browsers do not expose a programmatic install prompt; the website then shows instructions for adding it to the home screen.

## Important limitations before a real launch
- **No real payments:** the checkout is simulated. Do not use it to accept money.
- **No backend or accounts:** there is no order database, admin panel, secure product delivery, or customer account system.
- **Wallpaper assets:** the catalogue uses remote Unsplash image URLs as previews. Confirm licensing/usage terms and replace them with your own or properly licensed original assets before selling downloadable wallpaper files.
- **QR tool:** QRCode.js is loaded from a CDN, so QR generation needs internet access.
- **PDF tool:** the helper opens a print-ready page and relies on the browser's “Save as PDF” feature; it is not a full PDF editor.
- **Offline use:** the service worker caches the app shell. Remote wallpaper images, Google Fonts and the QR library may not be available offline.
- **Security:** real payments, paid file delivery and admin functions must be implemented server-side or with a trusted backend/service. Never put payment secrets in client-side JavaScript.

## Suggested next phase
Choose a static host and domain, replace sample artwork with licensed content, then add a backend for products/orders and integrate a payment gateway with server-side payment verification.
